def main():
    try:
        sisi = int(input("Masukkan jumlah sisi bangun ruang: "))

        if sisi <= 0:
            print("Jumlah sisi tidak valid!")
        else:
            if sisi == 0:  # seharusnya ga ada bangun ruang
                print("Tidak ada bangun ruang dengan 0 sisi.")
            else:
                if sisi == 4:  # bisa kubus atau balok
                    print("Bangun ruang dengan 4 sisi biasanya adalah Tetrahedron (limas segitiga).")
                    print("Namun, kita asumsikan yang umum: Balok/Kubus.")
                    pilihan = input("Hitung Kubus (k) atau Balok (b)? ").lower()

                    if pilihan == "k":
                        sisi_k = float(input("Masukkan panjang sisi kubus: "))
                        volume = sisi_k ** 3
                        print(f"Volume kubus adalah {volume}")
                    else:
                        if pilihan == "b":
                            p = float(input("Masukkan panjang: "))
                            l = float(input("Masukkan lebar: "))
                            t = float(input("Masukkan tinggi: "))
                            volume = p * l * t
                            print(f"Volume balok adalah {volume}")
                        else:
                            print("Pilihan tidak valid!")

                else:
                    if sisi == 3:  # Prisma segitiga
                        print("Bangun ruang dengan 3 sisi biasanya prisma segitiga.")
                        luas_alas = float(input("Masukkan luas alas segitiga: "))
                        tinggi = float(input("Masukkan tinggi prisma: "))
                        volume = luas_alas * tinggi
                        print(f"Volume prisma segitiga adalah {volume}")
                    else:
                        if sisi == 1:  # bola
                            print("Bangun ruang dengan 1 sisi: Bola")
                            r = float(input("Masukkan jari-jari bola: "))
                            volume = (4/3) * 3.14 * (r**3)
                            print(f"Volume bola adalah {volume}")
                        else:
                            print("Bangun ruang dengan jumlah sisi tersebut belum tersedia di aplikasi ini.")
    except ValueError:
        print("Input harus berupa angka!")

# jalankan program
main()
